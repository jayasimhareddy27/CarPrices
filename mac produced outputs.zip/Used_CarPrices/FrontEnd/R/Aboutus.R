AboutusUI <- function() {
  fluidPage(
    tags$head(
      tags$style(HTML("
        .about-header {
          text-align: center;
          font-size: 2.5rem;
          font-weight: bold;
          color: #2c3e50;
          margin-bottom: 20px;
        }
        .about-subtitle {
          text-align: center;
          font-size: 1.2rem;
          color: #7f8c8d;
          margin-bottom: 30px;
        }
        .about-content {
          margin: 0 auto;
          max-width: 800px;
          font-size: 1rem;
          line-height: 1.6;
          color: #34495e;
          text-align: justify;
        }
        .feature-section {
          margin-top: 30px;
        }
        .feature {
          margin-bottom: 20px;
        }
        .feature h5 {
          font-size: 1.2rem;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        .feature p {
          font-size: 0.95rem;
          color: #7f8c8d;
        }
        .about-footer {
          text-align: center;
          font-size: 0.9rem;
          color: #95a5a6;
          margin-top: 30px;
        }
      "))
    ),
    div(class = "about-header", "About Us"),
    div(class = "about-subtitle", 
        "Empowering users with innovative tools and insights."),
    div(class = "about-content",
        p("Our website is designed to provide seamless and intuitive solutions to help users achieve their goals efficiently. Whether you're here to make informed decisions, explore data-driven insights, or leverage advanced predictive models, our platform offers robust tools tailored to your needs."),
        p("We combine user-friendly interfaces with cutting-edge technology to deliver a superior experience. From car price predictions to detailed data visualizations, our tools are developed to ensure accuracy and reliability. We aim to bridge the gap between complex analytics and everyday usability.")
    ),
    div(class = "feature-section",
        div(class = "feature",
            h5("Predictive Analytics"),
            p("Leverage our predictive models to get accurate insights into your data, such as estimating car prices based on various factors.")
        ),
        div(class = "feature",
            h5("User-Friendly Interface"),
            p("Our intuitive interface ensures that even non-technical users can navigate and use the platform with ease.")
        ),
        div(class = "feature",
            h5("Data-Driven Insights"),
            p("Explore comprehensive visualizations and summaries to gain actionable insights from your data.")
        ),
        div(class = "feature",
            h5("Customizable Tools"),
            p("Tailor the features to suit your unique requirements, providing flexibility and control over the outputs.")
        )
    ),
    div(class = "about-footer", 
        "Our mission is to make complex analytics accessible to everyone. Thank you for choosing our platform!")
  )
}
