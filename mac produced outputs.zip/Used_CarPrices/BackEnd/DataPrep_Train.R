source("Global Variables.R")
source("./Functions/Core.R")
source("./Functions/Caller.R")

## clean Duplicate values
DealWith_Duplicates(Cars_Kaggle)

## clean missing values
ImputedData <- DealWith_MissingValues(Cars_Kaggle)

## Adding New column for category type of car
ImputedData <- ImputedData %>%
  mutate(Economy_Type = case_when(
    brand %in% c("Ferrari", "Lamborghini", "Bentley", "Rolls-Royce", "McLaren") ~ "Super Luxury",
    brand %in% c("Mercedes-Benz", "BMW", "Audi", "Jaguar", "Land Rover", "Porsche", "Tesla") ~ "Luxury",
    brand %in% c("Toyota", "Honda", "Ford", "Chevrolet", "Volkswagen", "Subaru", "Mazda") ~ "Mid-Range",
    brand %in% c("Hyundai", "Kia", "Nissan", "Mitsubishi", "FIAT") ~ "Economy",
    brand %in% c("Suzuki", "Dacia", "Tata", "smart", "Scion") ~ "Budget",
    TRUE ~ "Other"
  ))


## outliers
ImputedData <- DealWith_Outliers(ImputedData,Cars_Kaggle)


## extracting engine features
Engine_Featured_Data <- DealWith_ExtractingEngineFeatures(ImputedData)



## final iteration of missing values
Engine_Featured_Data <- DealWith_MissingValuesFinal(Engine_Featured_Data)


#Engine_Featured_Data_Scaled <- Engine_Featured_Data %>% mutate(price = log(price))

##  Conversions
ProcessedData <- DealWith_Converstions(Engine_Featured_Data)





## Feature selection using backward elimination is done already and these are main features obtained, 
#The code for this is commented since this is not required to run everytime

inds <- Splitter(ProcessedData)
Web_Purpose_ProcessedData <- ProcessedData 
write.csv(Web_Purpose_ProcessedData, file = "Datasets/Web_Purpose_ProcessedData.csv")
write.csv(Web_Purpose_ProcessedData, file = "../FrontEnd/DATASETS/Web_Purpose_ProcessedData.csv")

## Scaling Data
#ProcessedData <- Scaler_R(ProcessedData)


ProcessedData <- ProcessedData %>% select(c(price,
                                            brand,
                                            ModelYear=model_year,Milage=milage,EngineHorsepower=engine_horsepower,
                                            FuelType=fuel_type,Transmission=transmission,Accident=accident,
                                            EngineTechnology=engine_technology,EngineSpecial=engine_special,EngineConfiguration=engine_configuration)) 
# Dimensionality reduction
# reason for linear model: 
# feature selection has already been applied to remove unnecessary features, ensuring that the dataset retains only the most relevant ones, 
# It is not necessarily a condition to avoid dimension reduction technique if we apply feature selection but
# applying further Dimensionality reduction could risk removing valuable information. since the model is able to take less time after all the optimizations
# we concluded to not use Dimensionalityreduction

# reason for XGBoost: 
# XGBoost is designed to efficiently handle large feature sets and can automatically assess feature importance during training. 
# Due to its robust ability to capture complex relationships, Dimensionality reduction is not necessary. 
# In fact, reducing the feature set might remove important interactions that XGBoost could otherwise leverage for better predictions.



# split data

ProcessedData_Train <- ProcessedData[inds$train, ]
ProcessedData_Valid <- ProcessedData[inds$valid, ] 
ProcessedData_Test <- ProcessedData[inds$test, ] 

write.csv(ProcessedData, file = "Datasets/ProcessedData.csv")
write.csv(ProcessedData, file = "../FrontEnd/DATASETS/ProcessedData.csv")

write.csv(ProcessedData_Train, file = "Datasets/ProcessedData_Train.csv")
write.csv(ProcessedData_Train, file = "../FrontEnd/DATASETS/ProcessedData_Train.csv")


write.csv(ProcessedData_Test, file = "Datasets/ProcessedData_Test.csv")
write.csv(ProcessedData_Test, file = "../FrontEnd/DATASETS/ProcessedData_Test.csv")



## TRAIN DATA
OnehotencodedData <- OneHotEncoder_R(ProcessedData)
write.csv(OnehotencodedData, file = "Datasets/OnehotencodedData.csv")
write.csv(OnehotencodedData, file = "../FrontEnd/DATASETS/OnehotencodedData.csv")

source("./Models/Linearmodel.R")
source("./Models/XGBoost.R")



## Backward Eliminator
source("./Models/BackwardEliminator.R")



