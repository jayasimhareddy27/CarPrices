source("Models/Linear model.R")

#source("Models/XGBOOST.R")

# Apply backward elimination to reduce the features using confidence level == 95 percentage 
# optimize the model with hyper parameters using train, test and val sets
# print the summary of each model for understanding
# Comparing the models with statistics



#  predict
# prediction can be directly seen in website, we are listing 2 examples just for testing

Test_index <- 1:5

linear_pred <- abs(predict(Simple_LinearModel, ProcessedData_Test[Test_index,]))

one_hot_test <-  model.matrix(~ model + brand + milage + fuel_type + 
                                transmission + accident + engine_technology + engine_special + engine_configuration + engine_horsepower - 1,  
                              data = ProcessedData_Test[Test_index,])
dtest <- xgb.DMatrix(data = one_hot_test)
xgb_pred  <- predict(XGBOOST_model, dtest)

cat(paste("Linear Predicted value: ", linear_pred, 
          "\tXGBoost Predicted value: ", xgb_pred, 
          "\tActual Value: ", ProcessedData[inds$test, ]$price[Test_index]), 
    sep = "\n")



#  Regression model statistics
#print_model_summary(Simple_LinearModel)





