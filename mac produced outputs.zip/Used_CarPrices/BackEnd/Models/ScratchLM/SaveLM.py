import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import pickle
from multiple_linear_regression import MultipleLinearRegression



def tune_alpha_with_early_stopping(X_train, y_train, X_val, y_val, alpha_values, tolerance=1e-4, patience=3):
    best_alpha = None
    best_mse = float("inf")
    no_improve_count = 0

    for alpha in alpha_values:
        model = MultipleLinearRegression()
        model.fit(X_train, y_train, alpha=alpha)
        
        # Predict and calculate MSE
        y_pred = model.predict(X_val)
        mse = mean_squared_error(y_val, y_pred)
        print(f"Alpha: {alpha}, MSE: {mse}")

        # Check if improvement
        if mse < best_mse - tolerance:
            best_mse = mse
            best_alpha = alpha
            no_improve_count = 0  # Reset patience counter
        else:
            no_improve_count += 1  # Increment patience counter
        
        # Early stopping if no improvement over 'patience' rounds
        if no_improve_count >= patience:
            print("Early stopping activated.")
            break

    print(f"Best alpha: {best_alpha} with MSE: {best_mse}")
    return best_alpha


np.random.seed(42)
columns_to_scale = ['ModelYear', 'Milage', 'EngineHorsepower']

# Load data
print("Loading data...")
train_data = pd.read_csv('./Datasets/OnehotencodedData.csv', index_col=0)

# Standardize specified columns
scaler = StandardScaler()
X_train_df = train_data.drop(columns=['price'])
X_train_df[columns_to_scale] = scaler.fit_transform(X_train_df[columns_to_scale])



# Model ready datasets
X_train = X_train_df.values
y_train = train_data['price'].values
y_train = np.log(y_train)

# Split into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

# Grid search over a logarithmic scale of alpha values
alpha_values = np.logspace(-4, 4, 20)  # Increased granularity for alpha values
print("Starting alpha tuning with early stopping...")
best_alpha = tune_alpha_with_early_stopping(X_train, y_train, X_val, y_val, alpha_values)

# Train final model with the best alpha
print("Training final model with best alpha:", best_alpha)
final_model = MultipleLinearRegression()
final_model.fit(X_train, y_train, alpha=best_alpha)





# Save the model
model_pkl_file = "../FrontEnd/Save/SavedModels/LM.pkl"
with open(model_pkl_file, 'wb') as file:
    pickle.dump(final_model, file)
print(f"Model saved to {model_pkl_file}")

model_pkl_file = "Save/SavedModels/LM.pkl"
with open(model_pkl_file, 'wb') as file:
    pickle.dump(final_model, file)
print(f"Model saved to {model_pkl_file}")


# Save the column names to a text file
#train_columns = X_train_df.columns.tolist()
#with open("./Save/train_columns.txt", "w") as f:
#    for column in train_columns:
#        f.write(f"{column}\n")
#print("Training columns saved to train_columns.txt")

#with open("../FrontEnd/Save/train_columns.txt", "w") as f:
#    for column in train_columns:
#        f.write(f"{column}\n")
#print("Training columns saved to train_columns.txt")

