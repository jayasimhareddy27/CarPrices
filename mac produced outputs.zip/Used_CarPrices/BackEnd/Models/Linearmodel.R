library(reticulate)
#reticulate::py_install("pandas")
#reticulate::py_install("numpy")
#reticulate::py_install("pyreadr")
#reticulate::py_install("scipy")
#reticulate::py_install("scikit-learn")
py_config()




#Simple_LinearModel <- lm(price~.,data=ProcessedData_Train)




source_python("Models/ScratchLM/multiple_linear_regression.py")
source_python("Models/ScratchLM/SaveLM.py")




#Record1<- ProcessedData_Test %>% head(4) %>% select(-price)
#glimpse(Record1)

#source_python("Models/ScratchLM/loadLM_Predict.py")
#price<- predict_car_prices_LM(Record1)
 




