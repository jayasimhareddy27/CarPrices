one_hot_train <- model.matrix(~ model + brand + milage + fuel_type + 
                                transmission + accident + engine_technology + engine_special + engine_configuration + engine_horsepower - 1, 
                              data = ProcessedData_Train)
dtrain <- xgb.DMatrix(data = one_hot_train, label = ProcessedData_Train$price)

PARAMS <- list(
  booster = "gbtree",       
  objective = "reg:squarederror", 
  eta = 0.2,  
  max_depth = 4,            
  subsample = 0.8,          
  colsample_bytree = 0.8,
  min_child_weight = 5
)
nrounds <- 1000

XGBOOST_model <- xgb.train(
  params = PARAMS,
  data = dtrain,
  nrounds = nrounds,
  watchlist = list(train = dtrain),
  verbose = 2,
  early_stopping_rounds = 50
)



# XGBoost model
saveRDS(XGBOOST_model,file="Save/XGBoost.RDS")
capture.output(summary(XGBOOST_model), file = "Save/XGBoostmodel_summary.txt")




tune_grid <- expand.grid(
  eta = c(0.1, 0.2, 0.3),
  max_depth = c(3, 4, 5),
  subsample = c(0.7, 0.8, 0.9),
  colsample_bytree = c(0.7, 0.8, 0.9),
  min_child_weight = c(1, 5, 10)
)

best_params <- list()
best_rmse <- Inf  

for (i in 1:nrow(tune_grid)) {
  params <- list(
    booster = "gbtree",
    objective = "reg:squarederror",
    eta = tune_grid$eta[i],
    max_depth = tune_grid$max_depth[i],
    subsample = tune_grid$subsample[i],
    colsample_bytree = tune_grid$colsample_bytree[i],
    min_child_weight = tune_grid$min_child_weight[i]
  )
  
  # Perform cross-validation with early stopping
  cv <- xgb.cv(
    params = params,
    data = dtrain,
    nrounds = 1000,
    nfold = 5,
    early_stopping_rounds = 50,
    verbose = 0
  )
  
  # Check the best RMSE for this set of parameters
  mean_rmse <- min(cv$evaluation_log$test_rmse_mean)
  
  if (mean_rmse < best_rmse) {
    best_rmse <- mean_rmse
    best_params <- params
    best_nrounds <- cv$best_iteration
  }
}

# Print the best parameters and the number of rounds
print(best_params)
cat("Best RMSE:", best_rmse, "\n")
cat("Best nrounds:", best_nrounds, "\n")

# Train the model with the best parameters
XGBOOST_model <- xgb.train(
  params = best_params,
  data = dtrain,
  nrounds = best_nrounds
)
