library(reticulate)
#reticulate::py_install("pandas")
#reticulate::py_install("numpy")
#reticulate::py_install("pyreadr")
#reticulate::py_install("scipy")
#reticulate::py_install("scikit-learn")
py_config()






source_python("Models/ScratchXGBoost/Xgboost.py")
source_python("Models/ScratchXGBoost/SaveXGBoost.py")

Record1<- ProcessedData_Test %>% head(5) %>% select(-price)
glimpse(Record1)

source_python("Models/ScratchXGBoost/loadXGBoost_predict.py")
predict_car_prices_XGB(Record1)
